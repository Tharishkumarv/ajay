package com.easy.base;

public class TransactionException extends Exception {

	private static final long serialVersionUID = 1L;
	String errorCode = "";
	String errorMessage = "";

	public TransactionException(String errCode, String errMessage) {
		this.errorCode = errCode;
		this.errorMessage = errMessage;

	}
}
