package com.easy.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Page {

	private static Logger log = LoggerFactory.getLogger(Page.class);
	
	private Long pageSize;
	private Long lastRecordKey;
	private String outputOrdering;
	private Long recordCount;
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	public Long getLastRecordKey() {
		return lastRecordKey;
	}
	public void setLastRecordKey(Long lastRecordKey) {
		this.lastRecordKey = lastRecordKey;
	}
	public String getOutputOrdering() {
		return outputOrdering;
	}
	public void setOutputOrdering(String outputOrdering) {
		this.outputOrdering = outputOrdering;
	}
	public Long getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(Long recordCount) {
		this.recordCount = recordCount;
	}
	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();

			builder.append(" lastRecordKey=" + lastRecordKey);
			builder.append(" outputOrdering=" + outputOrdering);
			builder.append(" pageSize=" + pageSize);
			builder.append(" recordCount..=" + recordCount);

			return builder.toString();
		} else {
			return "pageSize=" + pageSize;
		}
	}
	
}
