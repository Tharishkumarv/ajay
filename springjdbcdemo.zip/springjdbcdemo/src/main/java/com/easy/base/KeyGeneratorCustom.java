package com.easy.base;

public class KeyGeneratorCustom {

	/**
	 * Some default implementation to generate unique key. Please have you own
	 * implementation.
	 * 
	 * @return
	 */
	public static synchronized Long getKey() {
		int num = (int) (Math.random() * 10000000);
		Long key = System.currentTimeMillis() + num;
		return key;
	}

}
