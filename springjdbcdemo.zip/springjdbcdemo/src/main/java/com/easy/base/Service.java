package com.easy.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface Service {

	public default CommonBean create(CommonBean bean, Map<String, Object> params)
			throws  TransactionException {

		return bean;
	}

	public default CommonBean update(CommonBean bean, Map<String, Object> params) throws TransactionException {

		return bean;
	}

	public default CommonBean manage(CommonBean bean, Map<String, Object> params) throws TransactionException {

		return bean;
	}

	public default CommonBean get(CommonBean bean, Map<String, Object> params) throws TransactionException {

		return bean;
	}


}
