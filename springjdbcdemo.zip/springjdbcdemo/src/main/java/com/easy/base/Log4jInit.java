package com.easy.base;

import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log4jInit extends HttpServlet {

	private static Logger logger = Logger.getLogger(Log4jInit.class.getName());

	public void init() {
		String prefix = getServletContext().getRealPath("/");
		prefix = prefix.trim();
		if ((prefix.endsWith("\\")) || (prefix.endsWith("/"))) {
			prefix = prefix + "";
		} else {
			prefix = prefix + "/";
		}

		String log4JconfigPath = prefix + "WEB-INF/log4j.properties";
		System.out.println("Log4J file to be used=" + log4JconfigPath);

		try {
			PropertyConfigurator.configure(log4JconfigPath);
			System.out.println("Log4J initialozation started: " + ".....");
			logger.debug("LOG4J initialization done..." + log4JconfigPath);
			System.out.println("Log4J  initialization Done: " + " for " + log4JconfigPath);
		} catch (Exception ex) {

			System.out.println("Log4J  initialization failed: " + " for " + log4JconfigPath);
		}

	}
}
