package com.easy.base;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonResponse {

	private static Logger log = Logger.getLogger(CommonResponse.class.getName());
	public String lockId = "";
	public String createTs;
	public String modifyTs;
	public String modifyUser;
	public String modifySystem;
	public String createUser;
	public String createSystem;
	public String status = "";
	public String message = "";
	public String errorCode = "";
	public String errorMessage = "";
	
	

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public static Logger getLog() {
		return log;
	}

	public static void setLog(Logger log) {
		CommonResponse.log = log;
	}

	public String getLockId() {
		return lockId;
	}

	public void setLockId(String lockId) {
		this.lockId = lockId;
	}

	public String getCreateTs() {
		return createTs;
	}

	public void setCreateTs(String createTs) {
		this.createTs = createTs;
	}

	public String getModifyTs() {
		return modifyTs;
	}

	public void setModifyTs(String modifyTs) {
		this.modifyTs = modifyTs;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getModifySystem() {
		return modifySystem;
	}

	public void setModifySystem(String modifySystem) {
		this.modifySystem = modifySystem;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateSystem() {
		return createSystem;
	}

	public void setCreateSystem(String createSystem) {
		this.createSystem = createSystem;
	}

	@Override
	public String toString() {

		String str = "";
		if (log.isDebugEnabled()) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				str = mapper.writeValueAsString(this);
				log.debug("ObjectValues:"+str);
			} catch (Exception e) {
				log.error(e + "", e);
			}
		} else {
			str = super.toString();
		}
		return str;
	}
}
