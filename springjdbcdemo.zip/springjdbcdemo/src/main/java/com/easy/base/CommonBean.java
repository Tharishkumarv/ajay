package com.easy.base;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonBean {

	private static Logger log = Logger.getLogger(CommonBean.class.getName());
	public Long lockId = 0l;
	public Timestamp createTs;
	public Timestamp modifyTs;
	public String modifyUser;
	public String modifySystem;
	public String createUser;
	public String createSystem;

	public static Logger getLog() {
		return log;
	}

	public static void setLog(Logger log) {
		CommonBean.log = log;
	}

	public Long getLockId() {
		return lockId;
	}

	public void setLockId(Long lockId) {
		this.lockId = lockId;
	}

	public Timestamp getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public Timestamp getModifyTs() {
		return modifyTs;
	}

	public void setModifyTs(Timestamp modifyTs) {
		this.modifyTs = modifyTs;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getModifySystem() {
		return modifySystem;
	}

	public void setModifySystem(String modifySystem) {
		this.modifySystem = modifySystem;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateSystem() {
		return createSystem;
	}

	public void setCreateSystem(String createSystem) {
		this.createSystem = createSystem;
	}

	@Override
	public String toString() {

		String str = "";
		if (log.isDebugEnabled()) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				str = mapper.writeValueAsString(this);
				log.debug("ObjectValues:" + str);
			} catch (Exception e) {
				log.error(e + "", e);
			}
		} else {
			str = super.toString();
		}
		return str;
	}
}
