package com.easy.base;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "Page")
public class PageRequest implements Serializable {

	private String pageSize = "";
	private String lastRecordKey = "0";
	private String outputOrdering = "DESC";
	private String recordCount = "";
	private static Logger log = LoggerFactory.getLogger(PageRequest.class);

	@XmlAttribute(name = "LastRecordKey")
	public String getLastRecordKey() {
		return lastRecordKey;
	}

	@XmlAttribute(name = "OutputOrdering")
	public String getOutputOrdering() {
		return outputOrdering;
	}

	@XmlAttribute(name = "PageSize")
	public String getPageSize() {
		return pageSize;
	}

	@XmlAttribute(name = "RecordCount")
	public String getRecordCount() {
		return recordCount;
	}

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();

			builder.append(" lastRecordKey=" + lastRecordKey);
			builder.append(" outputOrdering=" + outputOrdering);
			builder.append(" pageSize=" + pageSize);
			builder.append(" recordCount..=" + recordCount);

			return builder.toString();
		} else {
			return "pageSize=" + pageSize;
		}
	}

}
