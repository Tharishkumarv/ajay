package com.easy.base;

import org.apache.log4j.Logger;

public class BeanUtil {

	private static Logger log = Logger.getLogger(BeanUtil.class);

	public static CommonBean setAuditColumValuesForCreate(CommonBean commonBean) throws Exception {

		commonBean.setCreateTs(DateUtil.getCurrentTimestamp());
		if (commonBean.getCreateUser() == null) {
			commonBean.setCreateUser("SYSUSER");
		}
		if (commonBean.getCreateSystem() == null) {
			commonBean.setCreateSystem("SYSTEM");
		}

		String system = commonBean.getCreateSystem();

		commonBean.setModifySystem(system);
		commonBean.setModifyTs(DateUtil.getCurrentTimestamp());
		commonBean.setModifyUser(commonBean.getCreateUser());
		commonBean.setLockId(1L);
		return commonBean;
	}

	public static CommonBean setAuditColumValuesForUpdate(CommonBean commonBean) throws Exception {

		commonBean.setModifyTs(DateUtil.getCurrentTimestamp());

		if (commonBean.getModifySystem() == null) {
			commonBean.setModifySystem("MOD-SYSTEM");
		}
		if (commonBean.getModifyUser() == null) {
			commonBean.setModifyUser("MOD-USER");
		}

		return commonBean;
	}

	public static CommonBean setAuditColumnValuesForUpdate(CommonBean commonBean) throws Exception {

		return setAuditColumValuesForUpdate(commonBean);
	}

}
