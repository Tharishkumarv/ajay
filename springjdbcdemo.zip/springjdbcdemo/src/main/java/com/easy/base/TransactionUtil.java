package com.easy.base;

import org.apache.log4j.Logger;

public class TransactionUtil {
	private static Logger log = Logger.getLogger(TransactionUtil.class);

	public static TransactionException convertToTransactionException(Exception ex, String errorCode,
			String errorMessage) {
		log.error(ex.getMessage(), ex);
		TransactionException tex = new TransactionException(errorCode, errorMessage + "-" + ex);
		tex.setStackTrace(ex.getStackTrace());

		return tex;

	}
	public static TransactionException convertToTransactionException(Exception ex) {
		log.error(ex.getMessage(), ex);
		TransactionException tex = new TransactionException("DEFAULT", "" + "-" + ex);
		tex.setStackTrace(ex.getStackTrace());

		return tex;

	}


}
