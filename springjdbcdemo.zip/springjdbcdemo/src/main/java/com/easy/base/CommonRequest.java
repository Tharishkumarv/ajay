package com.easy.base;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonRequest {

	private static Logger log = Logger.getLogger(CommonRequest.class.getName());
	public int lockId = 0;
	public String createTs;
	public String modifyTs;
	public String modifyUser;
	public String modifySystem;
	public String createUser;
	public String createSystem;

	public static Logger getLog() {
		return log;
	}

	public static void setLog(Logger log) {
		CommonRequest.log = log;
	}

	public int getLockId() {
		return lockId;
	}

	public void setLockId(int lockId) {
		this.lockId = lockId;
	}

	
	public String getCreateTs() {
		return createTs;
	}

	public void setCreateTs(String createTs) {
		this.createTs = createTs;
	}

	public String getModifyTs() {
		return modifyTs;
	}

	public void setModifyTs(String modifyTs) {
		this.modifyTs = modifyTs;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getModifySystem() {
		return modifySystem;
	}

	public void setModifySystem(String modifySystem) {
		this.modifySystem = modifySystem;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateSystem() {
		return createSystem;
	}

	public void setCreateSystem(String createSystem) {
		this.createSystem = createSystem;
	}

	@Override
	public String toString() {

		String str = "";
		if (log.isDebugEnabled()) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				str = mapper.writeValueAsString(this);
				log.debug("ObjectValues:"+str);
			} catch (Exception e) {
				log.error(e + "", e);
			}
		} else {
			str = super.toString();
		}
		return str;
	}
}
