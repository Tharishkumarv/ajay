package com.easy.base;

public class CommonConstants {

	public static final String STATUS_FAILURE = "FAILED";
	public static final int DEFAULT_PAGE_SIZE = 20 ;

}
