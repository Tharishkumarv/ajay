package com.easy.base;

public class NumberUtil {

	public static Double convertToDouble(String noStr) {
		if (isInputNullOrEmpty(noStr))
			return null;

		return Double.parseDouble(noStr);
	}

	public static Double convertToDouble(String noStr, boolean returnZeroIfNull) {
		if (isInputNullOrEmpty(noStr)) {
			if (returnZeroIfNull)
				return 0.0;

			return null;
		}

		return Double.parseDouble(noStr);
	}

	public static Integer convertToInteger(String noStr, boolean returnZeroIfNull) {
		if (isInputNullOrEmpty(noStr)) {

			if (returnZeroIfNull)
				return 0;

			return null;
		}

		return Integer.parseInt(noStr);
	}

	public static Integer convertToInteger(String noStr) {
		if (isInputNullOrEmpty(noStr))
			return null;

		return Integer.parseInt(noStr);
	}

	public static Long convertToLong(String noStr, boolean returnZeroIfNull) {
		if (isInputNullOrEmpty(noStr)) {
			if (returnZeroIfNull)
				return 0L;
			return null;
		}
		return Long.parseLong(noStr);
	}

	public static Long convertToLong(String noStr) {
		if (isInputNullOrEmpty(noStr))
			return null;
		return Long.parseLong(noStr);
	}

	public static Float convertTofloat(String noStr, boolean returnZeroIfNull) {
		if (isInputNullOrEmpty(noStr)) {
			if (returnZeroIfNull)
				return 0f;

			return null;
		}
		return Float.parseFloat(noStr);
	}

	public static Float convertTofloat(String noStr) {
		if (isInputNullOrEmpty(noStr))
			return null;
		return Float.parseFloat(noStr);
	}

	public static Byte convertToByte(String noStr, boolean returnZeroIfNull) {
		if (isInputNullOrEmpty(noStr)) {
			if (returnZeroIfNull)
				return 0;
			return null;
		}
		return Byte.parseByte(noStr);
	}

	public static Byte convertToByte(String noStr) {
		if (isInputNullOrEmpty(noStr))
			return null;
		return Byte.parseByte(noStr);
	}

	private static boolean isInputNullOrEmpty(String noStr) {
		if (noStr == null)
			return true;
		if (noStr.trim().isEmpty())
			return true;
		return false;
	}

}
