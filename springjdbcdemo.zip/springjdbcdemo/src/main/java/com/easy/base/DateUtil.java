package com.easy.base;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

public class DateUtil {

	private final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.S";

	private static Logger logger = Logger.getLogger(DateUtil.class.getName());

	public static Timestamp convertToTimestampYYYYMMdd(String dateString) throws ParseException {

		DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		Date date = sdf.parse(dateString);

		dateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);

		Date dateInUtil = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateString);
		return new Timestamp(dateInUtil.getTime());

	}

	public static String getDateInyyyy_MM_ddHHmmss_S(Date date) {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		return formatter.format(date);

	}

	public static Date getDateFromStringInyyyy_MM_ddHHmmss_S(String dateStr) throws Exception {
		SimpleDateFormat formatter = null;
		if (dateStr.indexOf(':') > 0) {
			formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		} else {
			formatter = new SimpleDateFormat("yyyy-MM-dd");
		}
		return formatter.parse(dateStr);

	}

	public static String getDateAsStringInYYYYMMDD(Date date) {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return formatter.format(date);

	}

	public static String getTimeNowDateInAFormat(String formatStr) {

		Date date = new Date();

		SimpleDateFormat formatter = new SimpleDateFormat(formatStr);
		return formatter.format(date);

	}

	public static String getTimeNowDateInyyyy_MM_ddHHmmss_S() {

		Date date = new Date();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		return formatter.format(date);

	}

	public static String getDateOfToday(String formatStr) {
		return getTimeNowDateInAFormat(formatStr);
	}

	public static String getToday(String formatStr) {
		return getTimeNowDateInAFormat(formatStr);
	}

	public static String getTodayinYYYYMMDD() {

		Date date = new Date();
		System.out.println("date" + date);
		return getDateAsStringInYYYYMMDD(date);
	}

	public static Date getDateFromStringInYYYYMMDD(String dateStr) throws Exception {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return formatter.parse(dateStr);

	}

	public static String getCurrentDateInYYYYMMDD() throws Exception {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();

		System.out.println("date" + date);
		return getDateAsStringInYYYYMMDD(date);

	}

	public static Date getSystemDate() throws Exception {

		Date date = new Date();
		return date;

	}

	public static Date getSystemDateWithoutTime() throws Exception {

		return getCurrentDateWithOutTime();

	}

	public static String getCurrentDateInYYYYMMDD(String dateStr) throws Exception {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();

		System.out.println("date" + date);
		return getDateAsStringInYYYYMMDD(date);

	}

	public static int daysBetweenTwoDates(Date higherDate, Date lowerDate) {
		return (int) ((higherDate.getTime() - lowerDate.getTime()) / (1000 * 60 * 60 * 24));
	}

	public static int getAgeInDays(Date date) throws ParseException {
		Date lowerDate = date;
		Date higherDate = getCurrentDateWithOutTime();
		return (int) ((higherDate.getTime() - lowerDate.getTime()) / (1000 * 60 * 60 * 24));
	}

	public static long getTimeDffBetwn2Dates(Date higherDate, Date lowerDate) {
		return ((higherDate.getTime() - lowerDate.getTime()));
	}

	public static boolean isExpiredAsOfToday(Date dateToComp) {
		Date date = new Date();

		System.out.println("date" + date);
		return date.before(dateToComp);

	}

	public static boolean isExpiredAsOfToday(String dateToComp) throws Exception {
		Date date = new Date();

		logger.info("ExpierDateOfUser=" + dateToComp);
		boolean isExp = date.after(getDateFromStringInYYYYMMDD(dateToComp));
		logger.info("Expiered=" + isExp);
		return isExp;

	}

	public static String getDaysAfter90Days() {

		return getDaysAfter_N_Days(90);

	}

	public static String getDaysAfter_N_Days(int day) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, day);
		Date d = c.getTime();

		System.out.println("30 days after today is: " + d);

		return getDateAsStringInYYYYMMDD(d);

	}

	public static java.sql.Date convertToSqlDate(String dateStr) throws Exception {

		if (dateStr == null)
			return null;
		if (dateStr.trim().isEmpty())
			return null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		java.util.Date dateInUtil = formatter.parse(dateStr);
		return new java.sql.Date(dateInUtil.getTime());

	}

	public static java.sql.Date convertToSqlDate(java.util.Date dateInUtil) throws Exception {

		if (dateInUtil == null)
			return null;

		return new java.sql.Date(dateInUtil.getTime());

	}

	public static java.sql.Timestamp convertToSqlTimeStamp(String dateStr) throws Exception {

		if (dateStr == null)
			return null;
		if (dateStr.trim().isEmpty())
			return null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date dateInUtil = formatter.parse(dateStr);
		return new java.sql.Timestamp(dateInUtil.getTime());

	}

	public static java.sql.Timestamp convertToTimeStamp(String dateStr) throws Exception {

		return convertToSqlTimeStamp(dateStr);

	}

	public static java.sql.Date convertToDate(String dateStr) throws Exception {

		return convertToSqlDate(dateStr);

	}

	public static java.sql.Timestamp getCurrentTimestamp() throws Exception {

		return new Timestamp(System.currentTimeMillis());

	}

	public static java.sql.Timestamp getCurrentTimestampInYYYYMMdd() throws Exception {

		Date javaUtilDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return convertToSqlTimeStamp((formatter.format(javaUtilDate)));

	}

	public static java.sql.Date getDateAfter_N_Days(int day) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, day);
		Date date = c.getTime();
		return new java.sql.Date(date.getTime());
	}

	public static java.sql.Date getDateInSQL() {
		return getDateAfter_N_Days(0);
	}

	public static java.sql.Date getSysdateInSQl() {
		return getDateAfter_N_Days(0);
	}

	public static java.sql.Date getCurrentDateInSQl() {
		return getDateAfter_N_Days(0);
	}

	public static java.sql.Date getDateAfter_N_Hour(int hour) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.HOUR, hour);
		Date date = c.getTime();
		return new java.sql.Date(date.getTime());
	}

	public static java.sql.Date getFutureDate() {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, (365 * 1000));
		Date date = c.getTime();
		return new java.sql.Date(date.getTime());
	}

	public static java.sql.Date getDatePart(Date date) throws ParseException {

		if (date == null)
			return null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date dateWithoutTime = dateFormat.parse(dateFormat.format(date));
		return new java.sql.Date(dateWithoutTime.getTime());

	}

	public static Date getCurrentDateWithOutTime() throws ParseException {

		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date dateWithoutTime = dateFormat.parse(dateFormat.format(date));
		return dateWithoutTime;

	}

	public static boolean ispPastDateComparingDatePart(Date date) throws Exception {

		Date today = getSystemDateWithoutTime();
		Date paramDate = getDatePart(date);

		boolean isExp = today.after(paramDate);
		return isExp;

	}

}
