package com.easy.base;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "Page")
public class PageResponse {

	private static Logger log = LoggerFactory.getLogger(PageRequest.class);

	private String pageSize = "";
	private String lastRecordKey = "";
	private String outputOrdering = "";
	private String recordCount = "";

	@XmlAttribute(name = "LastRecordKey")
	public String getLastRecordKey() {
		return lastRecordKey;
	}

	@XmlAttribute(name = "OutputOrdering")
	public String getOutputOrdering() {
		return outputOrdering;
	}

	@XmlAttribute(name = "PageSize")
	public String getPageSize() {
		return pageSize;
	}

	@XmlAttribute(name = "RecordCount")
	public String getRecordCount() {
		return recordCount;
	}


	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();

			builder.append(" lastRecordKey=" + lastRecordKey);
			builder.append(" outputOrdering=" + outputOrdering);
			builder.append(" pageSize=" + pageSize);
			builder.append(" recordCount.=" + recordCount);

			return builder.toString();
		} else {
			return "pageSize=" + pageSize;
		}
	}

}
