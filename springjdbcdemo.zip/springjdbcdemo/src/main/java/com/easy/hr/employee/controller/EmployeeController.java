package com.easy.hr.employee.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.easy.base.CommonConstants;
import com.easy.hr.employee.bean.Employee;
import com.easy.hr.employee.bean.EmployeeRequest;
import com.easy.hr.employee.bean.EmployeeResponse;
import com.easy.hr.employee.service.EmployeeHelper;
import com.easy.hr.employee.service.EmployeeService;

@RestController
@RequestMapping(value = "/employee/", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
		MediaType.APPLICATION_JSON_VALUE })
public class EmployeeController {
	private static Logger log = Logger.getLogger(EmployeeController.class);
	@Autowired
	private EmployeeService EmployeeService;

	@RequestMapping(value = { "/create", "/", "" }, method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<EmployeeResponse> create(@RequestBody @Valid EmployeeRequest EmployeeRequest,
			BindingResult result) throws Exception {
		log.debug("Create Employee has been initiated.");
		
		System.out.println("Create EmployeeRequest="+EmployeeRequest);

		Employee Employee = EmployeeHelper.copyValuesFromRequestBeanToEntity(EmployeeRequest);
		EmployeeHelper.setAuditColumValuesForCreate(Employee);
		Employee = EmployeeHelper.setKeyColumnValue(Employee);
		EmployeeResponse EmployeeResponse = new EmployeeResponse();
		if (result.hasErrors()) {
			log.debug("errors" + result.getAllErrors());
			EmployeeResponse.setErrorMessage("" + result.getFieldErrors());
			EmployeeResponse.setErrorCode("INVALID_INPUT");
			EmployeeResponse.setStatus(CommonConstants.STATUS_FAILURE);
			return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.BAD_REQUEST);
		}
		Map<String, Object> params = new HashMap<String, Object>();
		Employee EmployeeOutputObj = (Employee) EmployeeService.create(Employee, params);

		EmployeeHelper.copyValuesFromEntityToResponse(EmployeeOutputObj, EmployeeResponse);
		return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.CREATED);

	}

	@RequestMapping(value = { "/update", "", "/" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<EmployeeResponse> update(@RequestBody @Valid EmployeeRequest EmployeeRequest,
			BindingResult result) throws Exception {
		log.debug("Update Employee has been initiated.");

		Employee Employee = EmployeeHelper.copyValuesFromRequestBeanToEntity(EmployeeRequest);
		EmployeeHelper.setAuditColumValuesForUpdate(Employee);
		EmployeeResponse EmployeeResponse = new EmployeeResponse();
		if (result.hasErrors()) {
			log.debug("errors" + result.getAllErrors());
			EmployeeResponse.setErrorCode("INVALID_INPUT");
			EmployeeResponse.setErrorMessage("Invlid Input. Error in binding from request to bean");
			return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.BAD_REQUEST);
		}
		CommonBean commonBean = EmployeeService.update(Employee, null);
		Employee EmployeeOutputObj = (Employee) commonBean;
		EmployeeHelper.copyValuesFromEntityToResponse(EmployeeOutputObj, EmployeeResponse);
		return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.OK);

	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<EmployeeResponse> delete(@RequestBody @Valid EmployeeRequest EmployeeRequest,
			BindingResult result) throws Exception {
		log.debug("Delete Employee has been initiated.");

		Employee Employee = EmployeeHelper.copyValuesFromRequestBeanToEntity(EmployeeRequest);
		EmployeeResponse EmployeeResponse = new EmployeeResponse();
		if (result.hasErrors()) {
			log.debug("errors" + result.getAllErrors());
			EmployeeResponse.setErrorCode("INVALID_INPUT");
			EmployeeResponse.setErrorMessage("Invlid Input. Error in binding from request to bean");
			return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.BAD_REQUEST);
		}
		CommonBean commonBean = EmployeeService.delete(Employee, null);
		Employee EmployeeOutputObj = (Employee) commonBean;
		EmployeeHelper.copyValuesFromEntityToResponse(EmployeeOutputObj, EmployeeResponse);
		return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.OK);

	}

	@RequestMapping(value = { "/get", "", "/" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<EmployeeResponse> get(@RequestBody @Valid EmployeeRequest EmployeeRequest,
			BindingResult result) throws Exception {
		log.debug("Get Employee has been initiated.");

		Employee Employee = EmployeeHelper.copyValuesFromRequestBeanToEntity(EmployeeRequest);
		EmployeeResponse EmployeeResponse = new EmployeeResponse();
		if (result.hasErrors()) {
			log.debug("errors" + result.getAllErrors());
			EmployeeResponse.setErrorCode("INVALID_INPUT");
			EmployeeResponse.setErrorMessage("Invlid Input. Error in binding from request to bean");
			return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.BAD_REQUEST);
		}
		CommonBean commonBean = EmployeeService.update(Employee, null);
		Employee EmployeeOutputObj = (Employee) commonBean;
		EmployeeHelper.copyValuesFromEntityToResponse(EmployeeOutputObj, EmployeeResponse);
		return new ResponseEntity<EmployeeResponse>(EmployeeResponse, HttpStatus.OK);

	}

}
