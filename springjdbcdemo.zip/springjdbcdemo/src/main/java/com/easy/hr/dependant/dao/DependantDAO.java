package com.easy.hr.dependant.dao;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.easy.hr.dependant.bean.Dependant;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
@PropertySource(value = { "classpath:dependant-dao.properties" })
public class DependantDAO {
	private static Logger log = Logger.getLogger(DependantDAO.class.getName());
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private NamedParameterJdbcTemplate namedJdbcTemplate;
	@Value(value = "${DependantDao.createDependant}")
	private String createDependantQuery;
	@Value(value = "${DependantDao.updateDependant}")
	private String updateDependantQuery;
	@Value(value = "${DependantDao.deleteDependant}")
	private String deleteDependantQuery;
	@Value(value = "${DependantDao.getDependant}")
	private String getDependantQuery;
	@Value(value = "${DependantDao.getDependantListByDependantKeyOtrs}")
	private String getDependantListByDependantKeyOtrs;
	@Value(value = "${DependantDao.getDependantListByDependantKeyList}")
	private String getDependantListByDependantKeyList;
	@Value(value = "${DependantDao.getDependantListByDynamicAttrs}")
	private String getDependantListByDynamicAttrs;
	@Value(value = "${DependantDao.getDependantListByDependantKeyOths}")
	private String getDependantListByDependantKeyOths;
	/** The batch insert size. */
	@Value(value = "${DependantDao.insertBatchSize}")
	private int batchInsertSize;

	/** The find Dependant query. */
	@Value(value = "${DependantDao.findDependantQuery}")
	private String findDependantQuery;

	public void createDependant(final Dependant Dependant) throws SQLException, DataAccessException {
		log.debug("createRecord start");
		log.debug("createRecord start");
		jdbcTemplate.execute(createDependantQuery, new PreparedStatementCallback<Object>() {
			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				int indx = 1;
				ps.setLong(indx++, Dependant.getDependantKey());
				ps.setLong(indx++, Dependant.getEmployeeKey());
				ps.setString(indx++, Dependant.getAge());
				ps.setString(indx++, Dependant.getLocation());
				ps.setString(indx++, Dependant.getName());
				ps.setString(indx++, Dependant.getRelation());
				ps.setLong(indx++, Dependant.getLockId());
				ps.setTimestamp(indx++, Dependant.getCreateTs());
				ps.setString(indx++, Dependant.getCreateUser());
				ps.setString(indx++, Dependant.getCreateSystem());
				ps.setTimestamp(indx++, Dependant.getModifyTs());
				ps.setString(indx++, Dependant.getModifyUser());
				ps.setString(indx++, Dependant.getModifySystem());

				return ps.executeUpdate();
			}
		});
	}

	public void updateDependant(final Dependant Dependant)
			throws JsonParseException, JsonMappingException, IOException {

		log.debug("updateDependant start");
		jdbcTemplate.execute(updateDependantQuery, new PreparedStatementCallback<Object>() {

			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				int indx = 1;
				ps.setLong(indx++, Dependant.getEmployeeKey());
				ps.setString(indx++, Dependant.getAge());
				ps.setString(indx++, Dependant.getLocation());
				ps.setString(indx++, Dependant.getName());
				ps.setString(indx++, Dependant.getRelation());
				ps.setLong(indx++, Dependant.getLockId());
				ps.setTimestamp(indx++, Dependant.getModifyTs());
				ps.setString(indx++, Dependant.getModifyUser());
				ps.setString(indx++, Dependant.getModifySystem());
				ps.setLong(indx++, Dependant.getDependantKey());

				int count = ps.executeUpdate();
				log.debug("Number of records updated=" + count);
				if (count == 0)
					throw new SQLException("STALE_DATA_ERROR");
				return count;

			}

		});
		log.debug("updateDependant end");

	}

	public void deleteDependant(final Dependant Dependant) throws IOException {
		log.debug("deleteDependant start");

		Long dependantKey = Dependant.getDependantKey();
		log.debug("Key.=" + dependantKey);

		jdbcTemplate.execute(deleteDependantQuery, new PreparedStatementCallback<Object>() {

			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ps.setLong(1, Dependant.getDependantKey());
				return ps.executeUpdate();
			}

		});
		log.debug("delete Dependant end");
	}

	public Dependant getDependant(Dependant Dependant) {
		Long dependantKey = Dependant.getDependantKey();

		log.debug("KeyCol for Get::" + dependantKey);
		Dependant DependantFromDB = null;
		try {

			DependantFromDB = jdbcTemplate.queryForObject(getDependantQuery, new Object[] { dependantKey },
					new BeanPropertyRowMapper<Dependant>(Dependant.class));
			log.debug("VAlue=::" + DependantFromDB);
		} catch (EmptyResultDataAccessException ex) {
			log.info("No Record Found. It Maybe expected." + ex.toString());
			return null;
		}

		return DependantFromDB;
	}

	public Dependant getDependantForUpdate(Dependant Dependant) {
		Long dependantKey = Dependant.getDependantKey();

		log.debug("KeyCol for Get::" + dependantKey);
		Dependant DependantFromDB = null;
		try {

			DependantFromDB = jdbcTemplate.queryForObject(getDependantQuery + " FOR UPDATE ",
					new Object[] { dependantKey }, new BeanPropertyRowMapper<Dependant>(Dependant.class));
			log.debug("VAlue=::" + DependantFromDB);
		} catch (EmptyResultDataAccessException ex) {
			log.info("NO RECORD. IT MAY BE EXPECTED." + ex.toString());
			return null;
		}

		return DependantFromDB;
	}

	public List<Dependant> getDependantListByDependantKeyAndOtrs(Dependant Dependant) {
		log.debug("Dependant::" + Dependant);
		Object[] parameters = new Object[] { Dependant.getDependantKey() };

		List<Dependant> DependantObjListFromDB = jdbcTemplate.query(getDependantListByDependantKeyOtrs, parameters,
				new BeanPropertyRowMapper<Dependant>(Dependant.class));

		log.debug("No.Of RecordFoundCount in list=::" + DependantObjListFromDB.size());
		return DependantObjListFromDB;
	}

	public Dependant getDependantByDependantKeyAndOtrs(Dependant Dependant) {
		List<Dependant> DependantObjListFromDB = getDependantListByDependantKeyAndOtrs(Dependant);
		Dependant DependantFromDB = null;

		if (DependantObjListFromDB.size() > 0) {
			DependantFromDB = DependantObjListFromDB.get(DependantObjListFromDB.size() - 1);
			log.debug("DependantFromDBVAlue=::" + DependantObjListFromDB.get(DependantObjListFromDB.size() - 1));
		}

		return DependantFromDB;
	}

	public List<Dependant> getDependantListByDependantKeyAndOths(Dependant Dependant) {
		log.debug("Dependant::" + Dependant);
		Object[] parameters = new Object[] { Dependant.getDependantKey() };

		List<Dependant> DependantObjListFromDB = jdbcTemplate.query(getDependantListByDependantKeyOths, parameters,
				new BeanPropertyRowMapper<Dependant>(Dependant.class));

		log.debug("No.Of RecordFoundCount in list=::" + DependantObjListFromDB.size());
		return DependantObjListFromDB;
	}

	public Dependant getDependantByDependantKeyAndOths(Dependant Dependant) {
		List<Dependant> DependantObjListFromDB = getDependantListByDependantKeyAndOths(Dependant);
		Dependant DependantFromDB = null;

		if (DependantObjListFromDB.size() > 0) {
			DependantFromDB = DependantObjListFromDB.get(DependantObjListFromDB.size() - 1);
			log.debug("DependantFromDBVAlue=::" + DependantObjListFromDB.get(DependantObjListFromDB.size() - 1));
		}

		return DependantFromDB;
	}

	public List<Dependant> getDependantListByDependantKeyList(List<Dependant> DependantList) {
		log.debug("DependantList::" + DependantList);
		String whereClause = " WHERE 1=2 ";
		List<Object> list = new ArrayList<Object>();
		for (Dependant Dependant : DependantList) {
			list.add(Dependant.getDependantKey());
			whereClause = whereClause + " OR DEPENDANT_KEY=? ";
		}

		Object[] parameters = list.toArray();

		List<Dependant> DependantObjListFromDB = jdbcTemplate.query(getDependantListByDependantKeyList + whereClause,
				parameters, new BeanPropertyRowMapper<Dependant>(Dependant.class));

		log.debug("No.Of RecordFoundCount in list=::" + DependantObjListFromDB.size());
		return DependantObjListFromDB;
	}

	public List<Dependant> getDependantListByDynamicAttrs(Dependant Dependant) {
		log.debug("Dependant::" + Dependant);
		List<Object> paramList = new ArrayList<Object>();
		String whereClause = " WHERE 1=1 ";
		if (Dependant.getDependantKey() != null) {
			whereClause = whereClause + " AND DEPENDANT_KEY=? ";
			paramList.add(Dependant.getDependantKey());
		}
		if (Dependant.getEmployeeKey() != null) {
			whereClause = whereClause + " AND EMPLOYEE_KEY=? ";
			paramList.add(Dependant.getEmployeeKey());
		}
		if (Dependant.getAge() != null) {
			whereClause = whereClause + " AND AGE=? ";
			paramList.add(Dependant.getAge());
		}
		if (Dependant.getLocation() != null) {
			whereClause = whereClause + " AND LOCATION=? ";
			paramList.add(Dependant.getLocation());
		}
		if (Dependant.getName() != null) {
			whereClause = whereClause + " AND NAME=? ";
			paramList.add(Dependant.getName());
		}
		if (Dependant.getRelation() != null) {
			whereClause = whereClause + " AND RELATION=? ";
			paramList.add(Dependant.getRelation());
		}

		Object[] parameters = paramList.toArray();

		log.debug("DynamicSQL::" + getDependantListByDynamicAttrs + whereClause);
		List<Dependant> DependantObjListFromDB = jdbcTemplate.query(getDependantListByDynamicAttrs + whereClause,
				parameters, new BeanPropertyRowMapper<Dependant>(Dependant.class));

		log.debug("No.Of RecordFoundCount in list=::" + DependantObjListFromDB.size());
		return DependantObjListFromDB;
	}

	public void insertDependantBatch(List<Dependant> DependantList) throws SQLException {
		for (int i = 0; i < DependantList.size(); i += this.batchInsertSize) {
			final List<Dependant> DependantBatch = DependantList.subList(i,
					i + this.batchInsertSize > DependantList.size() ? DependantList.size() : i + batchInsertSize);
			int[] noOfDependantsInserted = jdbcTemplate.batchUpdate(this.createDependantQuery,
					new BatchPreparedStatementSetter() {
						public void setValues(PreparedStatement pStmt, int j) throws SQLException {
							Dependant Dependant = (Dependant) DependantBatch.get(j);
							int indx = 1;
							pStmt.setLong(indx++, Dependant.getDependantKey());
							pStmt.setLong(indx++, Dependant.getEmployeeKey());
							pStmt.setString(indx++, Dependant.getAge());
							pStmt.setString(indx++, Dependant.getLocation());
							pStmt.setString(indx++, Dependant.getName());
							pStmt.setString(indx++, Dependant.getRelation());
							pStmt.setLong(indx++, Dependant.getLockId());
							pStmt.setTimestamp(indx++, Dependant.getCreateTs());
							pStmt.setString(indx++, Dependant.getCreateUser());
							pStmt.setString(indx++, Dependant.getCreateSystem());
							pStmt.setTimestamp(indx++, Dependant.getModifyTs());
							pStmt.setString(indx++, Dependant.getModifyUser());
							pStmt.setString(indx++, Dependant.getModifySystem());
							ObjectMapper mapper = new ObjectMapper();
							// Java objects to JSON string
							String jsonString = "";

							log.debug("attributes json" + jsonString);
							pStmt.setString(indx++, jsonString);
						}

						public int getBatchSize() {
							return DependantBatch.size();
						}
					});
			log.debug("insertDependantsBatch end");
		}
	}

//##PLACE_FOR_PUB_API_DAO_CODE##// 
}
