package com.easy.hr.employee.bean;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Employees extends CommonBean {

	private static Logger log = Logger.getLogger(Employees.class.getName());
	private static final long serialVersionUID = 1L;
	@JsonProperty("Employee")
	private List<Employee> EmployeeList = new ArrayList();

	public List<Employee> getEmployeeList() {
		return EmployeeList;
	}

	public void setEmployeeList(List<Employee> EmployeeList) {
		this.EmployeeList = EmployeeList;
	}
}
