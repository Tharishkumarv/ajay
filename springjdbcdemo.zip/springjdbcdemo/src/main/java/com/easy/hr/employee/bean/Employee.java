package com.easy.hr.employee.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.easy.hr.dependant.bean.Dependants;
import com.fasterxml.jackson.annotation.JsonProperty;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "Employee")
public class Employee extends CommonBean {
	private static Logger log = Logger.getLogger(Employee.class);
	@JsonProperty("dependants")
	Dependants dependants;
	private Long employeeKey;
	private String department;
	private String designation;
	private String employeeNo;
	private String firstName;
	private String lastName;

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();
			builder.append("\n employeeKey=" + employeeKey);
			builder.append("\n department=" + department);
			builder.append("\n designation=" + designation);
			builder.append("\n employeeNo=" + employeeNo);
			builder.append("\n firstName=" + firstName);
			builder.append("\n lastName=" + lastName);
			builder.append("\n lockId=" + lockId);
			builder.append("\n createTs=" + createTs);
			builder.append("\n createUser=" + createUser);
			builder.append("\n createSystem=" + createSystem);
			builder.append("\n modifyTs=" + modifyTs);
			builder.append("\n modifyUser=" + modifyUser);
			builder.append("\n modifySystem=" + modifySystem);
			return builder.toString();
		} else {
			return "employeeKey=" + employeeKey;
		}
	}

	@XmlAttribute(name = "EMPLOYEEKEY")
	public Long getEmployeeKey() {
		return employeeKey;
	}

	public void setEmployeeKey(Long employeeKey) {
		this.employeeKey = employeeKey; // ForDebugging no.9989
	}

	@XmlAttribute(name = "DEPARTMENT")
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department; // ForDebugging no.9989
	}

	@XmlAttribute(name = "DESIGNATION")
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation; // ForDebugging no.9989
	}

	@XmlAttribute(name = "EMPLOYEENO")
	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo; // ForDebugging no.9989
	}

	@XmlAttribute(name = "FIRSTNAME")
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName; // ForDebugging no.9989
	}

	@XmlAttribute(name = "LASTNAME")
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName; // ForDebugging no.9989
	}

	@XmlElement(name = "Dependants")
	public Dependants getDependants() {
		if (dependants == null)
			dependants = new Dependants();
		return dependants;
	}

	public void setDependants(Dependants dependants) {
		this.dependants = dependants;
	}
}
