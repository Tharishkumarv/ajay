package com.easy.hr.dependant.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "Dependant")
public class Dependant extends CommonBean {
	private static Logger log = Logger.getLogger(Dependant.class);
	private Long dependantKey;
	private Long employeeKey;
	private String age;
	private String location;
	private String name;
	private String relation;

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();
			builder.append("\n dependantKey=" + dependantKey);
			builder.append("\n employeeKey=" + employeeKey);
			builder.append("\n age=" + age);
			builder.append("\n location=" + location);
			builder.append("\n name=" + name);
			builder.append("\n relation=" + relation);
			builder.append("\n lockId=" + lockId);
			builder.append("\n createTs=" + createTs);
			builder.append("\n createUser=" + createUser);
			builder.append("\n createSystem=" + createSystem);
			builder.append("\n modifyTs=" + modifyTs);
			builder.append("\n modifyUser=" + modifyUser);
			builder.append("\n modifySystem=" + modifySystem);
			return builder.toString();
		} else {
			return "dependantKey=" + dependantKey;
		}
	}

	@XmlAttribute(name = "DEPENDANTKEY")
	public Long getDependantKey() {
		return dependantKey;
	}

	public void setDependantKey(Long dependantKey) {
		this.dependantKey = dependantKey; // ForDebugging no.9989
	}

	@XmlAttribute(name = "EmployeeKey")
	public Long getEmployeeKey() {
		return employeeKey;
	}

	public void setEmployeeKey(Long employeeKey) {
		this.employeeKey = employeeKey; // ForDebugging no.9989
	}

	@XmlAttribute(name = "AGE")
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age; // ForDebugging no.9989
	}

	@XmlAttribute(name = "LOCATION")
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location; // ForDebugging no.9989
	}

	@XmlAttribute(name = "NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name; // ForDebugging no.9989
	}

	@XmlAttribute(name = "RELATION")
	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation; // ForDebugging no.9989
	}

}
