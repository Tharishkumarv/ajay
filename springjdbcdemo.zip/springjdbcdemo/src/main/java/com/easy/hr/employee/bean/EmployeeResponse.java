package com.easy.hr.employee.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;
import java.util.*;
import org.apache.log4j.*;
//IMPORT_ALL_BEAN_CLASS
import com.easy.base.*;
import com.easy.hr.employee.bean.*;
import com.easy.hr.employee.service.*;
import com.easy.hr.dependant.bean.*;
import com.easy.hr.dependant.service.*;

//import lombok.Getter;
//import lombok.Setter;
import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;
//import lombok.Getter;
//import lombok.Setter;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "Employee")
public class EmployeeResponse extends CommonResponse {
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(EmployeeResponse.class);
	@JsonProperty("dependants")
	DependantsResponse dependantsResponse;

	@XmlElement(name = "Dependants")
	public DependantsResponse getDependantsResponse() {
		if (dependantsResponse == null)
			dependantsResponse = new DependantsResponse();
		return dependantsResponse;
	}

	public void setDependantsResponse(DependantsResponse dependantsResponse) {
		this.dependantsResponse = dependantsResponse;
	}

	private String employeeKey;
	private String department;
	private String designation;
	private String employeeNo;
	private String firstName;
	private String lastName;

	

	public static Logger getLog() {
		return log;
	}

	public static void setLog(Logger log) {
		EmployeeResponse.log = log;
	}

	public String getEmployeeKey() {
		return employeeKey;
	}

	public void setEmployeeKey(String employeeKey) {
		this.employeeKey = employeeKey;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();
			builder.append("\n employeeKey=" + employeeKey);
			builder.append("\n department=" + department);
			builder.append("\n designation=" + designation);
			builder.append("\n employeeNo=" + employeeNo);
			builder.append("\n firstName=" + firstName);
			builder.append("\n lastName=" + lastName);
			builder.append("\n lockId=" + lockId);
			builder.append("\n createTs=" + createTs);
			builder.append("\n createUser=" + createUser);
			builder.append("\n createSystem=" + createSystem);
			builder.append("\n modifyTs=" + modifyTs);
			builder.append("\n modifyUser=" + modifyUser);
			builder.append("\n modifySystem=" + modifySystem);
			return builder.toString();
		} else {
			return "employeeKey=" + employeeKey;
		}
	}

}
