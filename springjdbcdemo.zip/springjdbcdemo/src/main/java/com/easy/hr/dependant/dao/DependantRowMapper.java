package com.easy.hr.dependant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.easy.hr.dependant.bean.Dependant;

public class DependantRowMapper implements RowMapper<Dependant> {
	private static Logger log = Logger.getLogger(DependantRowMapper.class.getName());

	public Dependant mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		Dependant Dependant = new Dependant();
		Dependant.setDependantKey(resultSet.getLong("DEPENDANT_KEY"));
		Dependant.setEmployeeKey(resultSet.getLong("EMPLOYEE_KEY"));
		Dependant.setAge(resultSet.getString("AGE"));
		Dependant.setLocation(resultSet.getString("LOCATION"));
		Dependant.setName(resultSet.getString("NAME"));
		Dependant.setRelation(resultSet.getString("RELATION"));
		Dependant.setLockId(resultSet.getLong("LOCK_ID"));
		Dependant.setCreateTs(resultSet.getTimestamp("CREATE_TS"));
		Dependant.setCreateUser(resultSet.getString("CREATE_USER"));
		Dependant.setCreateSystem(resultSet.getString("CREATE_SYSTEM"));
		Dependant.setModifyTs(resultSet.getTimestamp("MODIFY_TS"));
		Dependant.setModifyUser(resultSet.getString("MODIFY_USER"));
		Dependant.setModifySystem(resultSet.getString("MODIFY_SYSTEM"));
		return Dependant;
	};
}
