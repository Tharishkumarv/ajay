package com.easy.hr.dependant.bean;

import java.util.ArrayList;
import java.util.List;

//import lombok.Getter;
//import lombok.Setter;
import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonResponse;
//import lombok.Getter;
//import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

//import lombok.Getter;
//import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
public class DependantsResponse extends CommonResponse {

	private static Logger log = Logger.getLogger(DependantsResponse.class);
	private static final long serialVersionUID = 1L;
	@JsonProperty("dependant")
	@XmlElement(name = "Dependant")
	private List<DependantResponse> dependantResponseList = new ArrayList();

	public List<DependantResponse> getDependantResponseList() {
		return dependantResponseList;
	}

	public void setDependantResponseList(List<DependantResponse> dependantResponseList) {
		this.dependantResponseList = dependantResponseList;
	}

}
