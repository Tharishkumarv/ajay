package com.easy.hr.dependant.bean;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Dependants extends CommonBean {

	private static Logger log = Logger.getLogger(Dependants.class.getName());
	private static final long serialVersionUID = 1L;
	@JsonProperty("Dependant")
	private List<Dependant> DependantList = new ArrayList();

	public List<Dependant> getDependantList() {
		return DependantList;
	}

	public void setDependantList(List<Dependant> DependantList) {
		this.DependantList = DependantList;
	}
}
