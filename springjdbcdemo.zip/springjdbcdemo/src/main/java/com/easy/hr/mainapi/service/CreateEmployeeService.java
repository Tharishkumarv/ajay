package com.easy.hr.mainapi.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.easy.base.Service;
import com.easy.base.TransactionException;
import com.easy.base.TransactionUtil;
import com.easy.hr.dependant.bean.Dependant;
import com.easy.hr.dependant.bean.Dependants;
import com.easy.hr.dependant.service.DependantHelper;
import com.easy.hr.dependant.service.DependantService;
import com.easy.hr.employee.bean.Employee;
import com.easy.hr.employee.service.EmployeeHelper;
import com.easy.hr.employee.service.EmployeeService;

@org.springframework.stereotype.Service
public class CreateEmployeeService implements Service {
	private static Logger log = Logger.getLogger(CreateEmployeeService.class);
	@Autowired
	EmployeeService employeeService;
	@Autowired
	DependantService dependantService;

	@Override
	public CommonBean create(CommonBean commonBean, Map<String, Object> params) throws TransactionException {

		try {
			Employee employee = (Employee) commonBean;
			EmployeeHelper.setAuditColumValuesForCreate(employee);
			employee = EmployeeHelper.setKeyColumnValue(employee);

			Object employeeObj = employeeService.manage(employee, params);
			employee = (Employee) employeeObj;
			Long employeeKey = employee.getEmployeeKey();
			if (employeeKey == null)
				throw new TransactionException("employeeKeyIsNull", "employeeKeyIsNull");
			Dependants dependants = employee.getDependants();
			List<Dependant> dependantList = dependants.getDependantList();
			for (Dependant dependant : dependantList) {

				DependantHelper.setAuditColumValuesForCreate(dependant);
				dependant = DependantHelper.setKeyColumnValue(dependant);
				dependant.setEmployeeKey(employeeKey);

				Object objDependant = dependantService.manage(dependant, params);
				dependant = (Dependant) objDependant;
				Long dependantKey = dependant.getDependantKey();
			}
			return employee;
		} catch (Exception ex) {
			throw TransactionUtil.convertToTransactionException(ex, "MAIN_API_CREATE_EXCEPTION",
					"Exception in create public api. Check stacktrace for details.");
		}
	}
}
