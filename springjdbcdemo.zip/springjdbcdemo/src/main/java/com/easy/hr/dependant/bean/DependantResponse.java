package com.easy.hr.dependant.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;
import java.util.*;
import org.apache.log4j.*;
//IMPORT_ALL_BEAN_CLASS
import com.easy.base.*;
import com.easy.hr.employee.bean.*;
import com.easy.hr.employee.service.*;
import com.easy.hr.dependant.bean.*;
import com.easy.hr.dependant.service.*;

//import lombok.Getter;
//import lombok.Setter;
import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;
//import lombok.Getter;
//import lombok.Setter;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "Dependant")
public class DependantResponse extends CommonResponse {
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(DependantResponse.class);
	private String dependantKey;
	private String employeeKey;
	private String age;
	private String location;
	private String name;
	private String relation;

	public static Logger getLog() {
		return log;
	}

	public static void setLog(Logger log) {
		DependantResponse.log = log;
	}

	public String getDependantKey() {
		return dependantKey;
	}

	public void setDependantKey(String dependantKey) {
		this.dependantKey = dependantKey;
	}

	public String getEmployeeKey() {
		return employeeKey;
	}

	public void setEmployeeKey(String employeeKey) {
		this.employeeKey = employeeKey;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			StringBuilder builder = new StringBuilder();
			builder.append("\n dependantKey=" + dependantKey);
			builder.append("\n employeeKey=" + employeeKey);
			builder.append("\n age=" + age);
			builder.append("\n location=" + location);
			builder.append("\n name=" + name);
			builder.append("\n relation=" + relation);
			builder.append("\n lockId=" + lockId);
			builder.append("\n createTs=" + createTs);
			builder.append("\n createUser=" + createUser);
			builder.append("\n createSystem=" + createSystem);
			builder.append("\n modifyTs=" + modifyTs);
			builder.append("\n modifyUser=" + modifyUser);
			builder.append("\n modifySystem=" + modifySystem);
			return builder.toString();
		} else {
			return "dependantKey=" + dependantKey;
		}
	}

}
