package com.easy.hr.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.BeanUtil;
import com.easy.base.DateUtil;
import com.easy.base.KeyGeneratorCustom;
import com.easy.base.NumberUtil;
import com.easy.hr.employee.bean.Employee;
import com.easy.hr.employee.bean.EmployeeRequest;
import com.easy.hr.employee.bean.EmployeeResponse;
import com.easy.hr.employee.bean.EmployeesRequest;

public class EmployeeHelper {
	private static Logger log = Logger.getLogger(EmployeeHelper.class);

	public static Employee copyValuesFromRequestBeanToEntity(EmployeeRequest EmployeeRequest) throws Exception {
		Employee Employee = new Employee();
		Employee.setEmployeeKey(NumberUtil.convertToLong(EmployeeRequest.getEmployeeKey()));
		Employee.setDepartment(EmployeeRequest.getDepartment());
		Employee.setDesignation(EmployeeRequest.getDesignation());
		Employee.setEmployeeNo(EmployeeRequest.getEmployeeNo());
		Employee.setFirstName(EmployeeRequest.getFirstName());
		Employee.setLastName(EmployeeRequest.getLastName());
		Employee.setCreateTs(DateUtil.convertToTimeStamp(EmployeeRequest.getCreateTs()));
		Employee.setCreateUser(EmployeeRequest.getCreateUser());
		Employee.setCreateSystem(EmployeeRequest.getCreateSystem());
		Employee.setModifyTs(DateUtil.convertToTimeStamp(EmployeeRequest.getModifyTs()));
		Employee.setModifyUser(EmployeeRequest.getModifyUser());
		Employee.setModifySystem(EmployeeRequest.getModifySystem());
		return Employee;
	}

	public static EmployeeResponse copyValuesFromEntityToResponse(Employee Employee,
			EmployeeResponse EmployeeResponse) {
		EmployeeResponse.setEmployeeKey("" + Employee.getEmployeeKey());
		EmployeeResponse.setDepartment(Employee.getDepartment());
		EmployeeResponse.setDesignation(Employee.getDesignation());
		EmployeeResponse.setEmployeeNo(Employee.getEmployeeNo());
		EmployeeResponse.setFirstName(Employee.getFirstName());
		EmployeeResponse.setLastName(Employee.getLastName());
		EmployeeResponse.setLockId("" + Employee.getLockId());
		EmployeeResponse.setCreateTs("" + Employee.getCreateTs());
		EmployeeResponse.setCreateUser(Employee.getCreateUser());
		EmployeeResponse.setCreateSystem(Employee.getCreateSystem());
		EmployeeResponse.setModifyTs("" + Employee.getModifyTs());
		EmployeeResponse.setModifyUser(Employee.getModifyUser());
		EmployeeResponse.setModifySystem(Employee.getModifySystem());
		return EmployeeResponse;
	}

	public static List<Employee> copyValuesFromReqBeanListToEntityList(EmployeesRequest employeesRequest)
			throws Exception {

		List<EmployeeRequest> EmployeeRequestList = employeesRequest.getEmployeeRequestList();
		List<Employee> EmployeeList = new ArrayList<Employee>();
		for (int i = 0; i < EmployeeRequestList.size(); i++) {
			EmployeeRequest EmployeeRequest = EmployeeRequestList.get(i);
			Employee Employee = EmployeeHelper.copyValuesFromRequestBeanToEntity(EmployeeRequest);
			EmployeeList.add(Employee);
		}
		return EmployeeList;
	}

	public static Employee setAuditColumValuesForCreate(Employee Employee) throws Exception {
		Employee = (Employee) BeanUtil.setAuditColumValuesForCreate(Employee);
		log.debug("AfterSetting AuditColm Employee=" + Employee);
		return Employee;

	}

	public static Employee setKeyColumnValue(Employee Employee) throws Exception {

		if ((Employee.getEmployeeKey() == null) || (Employee.getEmployeeKey() == 0)) {
			Long key = KeyGeneratorCustom.getKey();
			Employee.setEmployeeKey(key);
		}
		return Employee;

	}

	public static Employee setAuditColumValuesForUpdate(Employee Employee) throws Exception {
		BeanUtil.setAuditColumValuesForUpdate(Employee);
		return Employee;
	}

}
