package com.easy.hr.dependant.controller;
import java.util.*;
import javax.validation.Valid;
import org.apache.log4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
//IMPORT_ALL_BEAN_CLASS
import com.easy.base.*; 
import com.easy.hr.employee.bean.*; 
import com.easy.hr.employee.service.*; 
import com.easy.hr.dependant.bean.*; 
import com.easy.hr.dependant.service.*; 


@RestController
@RequestMapping(value = "/dependant/",produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
public class DependantController {
private static Logger log = Logger.getLogger(DependantController.class );
@Autowired
private DependantService DependantService;
@RequestMapping(value = {"/create","/",""}, method=RequestMethod.PUT)
@ResponseStatus(HttpStatus.CREATED)
public ResponseEntity<DependantResponse> create(@RequestBody @Valid DependantRequest DependantRequest, BindingResult result) throws Exception {
log.debug("Create Dependant has been initiated.");

Dependant Dependant = DependantHelper.copyValuesFromRequestBeanToEntity(DependantRequest); 
DependantHelper.setAuditColumValuesForCreate(Dependant);
 Dependant = DependantHelper.setKeyColumnValue(Dependant);
DependantResponse DependantResponse = new DependantResponse(); 
if(result.hasErrors()) {
log.debug("errors" + result.getAllErrors());
DependantResponse.setErrorMessage(""+result.getFieldErrors());
DependantResponse.setErrorCode("INVALID_INPUT");
DependantResponse.setStatus(CommonConstants.STATUS_FAILURE);
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.BAD_REQUEST);
}
Map<String, Object> params = new HashMap<String, Object>();
Dependant DependantOutputObj = (Dependant)DependantService.create(Dependant, params);
 
DependantHelper.copyValuesFromEntityToResponse(DependantOutputObj, DependantResponse);
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.CREATED);

}

@RequestMapping(value = {"/update","","/"}, method=RequestMethod.POST)
@ResponseStatus(HttpStatus.OK)
public ResponseEntity<DependantResponse> update(@RequestBody @Valid DependantRequest DependantRequest, BindingResult result) throws Exception  {
log.debug("Update Dependant has been initiated.");

Dependant Dependant = DependantHelper.copyValuesFromRequestBeanToEntity(DependantRequest); 
DependantHelper.setAuditColumValuesForUpdate(Dependant);
DependantResponse DependantResponse = new DependantResponse(); 
if(result.hasErrors()) {
log.debug("errors" + result.getAllErrors());
DependantResponse.setErrorCode("INVALID_INPUT");
DependantResponse.setErrorMessage("Invlid Input. Error in binding from request to bean");
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.BAD_REQUEST);
}
CommonBean commonBean=DependantService.update(Dependant, null);
 Dependant DependantOutputObj = (Dependant) commonBean;
DependantHelper.copyValuesFromEntityToResponse(DependantOutputObj, DependantResponse);
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.OK);

}

@RequestMapping(value = "/delete", method=RequestMethod.DELETE)
@ResponseStatus(HttpStatus.OK)
public ResponseEntity<DependantResponse> delete(@RequestBody @Valid DependantRequest DependantRequest, BindingResult result) throws Exception  {
log.debug("Delete Dependant has been initiated.");

Dependant Dependant = DependantHelper.copyValuesFromRequestBeanToEntity(DependantRequest); 
DependantResponse DependantResponse = new DependantResponse(); 
if(result.hasErrors()) {
log.debug("errors" + result.getAllErrors());
DependantResponse.setErrorCode("INVALID_INPUT");
DependantResponse.setErrorMessage("Invlid Input. Error in binding from request to bean");
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.BAD_REQUEST);
}
CommonBean commonBean=DependantService.delete(Dependant, null);
 Dependant DependantOutputObj = (Dependant) commonBean;
DependantHelper.copyValuesFromEntityToResponse(DependantOutputObj, DependantResponse);
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.OK);

}

@RequestMapping(value = {"/get","","/"}, method=RequestMethod.GET)
@ResponseStatus(HttpStatus.OK)
public ResponseEntity<DependantResponse> get(@RequestBody @Valid DependantRequest DependantRequest, BindingResult result) throws Exception  {
log.debug("Get Dependant has been initiated.");

Dependant Dependant = DependantHelper.copyValuesFromRequestBeanToEntity(DependantRequest); 
DependantResponse DependantResponse = new DependantResponse(); 
if(result.hasErrors()) {
log.debug("errors" + result.getAllErrors());
DependantResponse.setErrorCode("INVALID_INPUT");
DependantResponse.setErrorMessage("Invlid Input. Error in binding from request to bean");
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.BAD_REQUEST);
}
CommonBean commonBean=DependantService.update(Dependant, null);
 Dependant DependantOutputObj = (Dependant) commonBean;
DependantHelper.copyValuesFromEntityToResponse(DependantOutputObj, DependantResponse);
return new ResponseEntity<DependantResponse>(DependantResponse, HttpStatus.OK);

}



}
