
package com.easy.hr.dependant.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.BeanUtil;
import com.easy.base.DateUtil;
import com.easy.base.KeyGeneratorCustom;
import com.easy.base.NumberUtil;
import com.easy.hr.dependant.bean.Dependant;
import com.easy.hr.dependant.bean.DependantRequest;
import com.easy.hr.dependant.bean.DependantResponse;
import com.easy.hr.dependant.bean.DependantsRequest;

public class DependantHelper {
	private static Logger log = Logger.getLogger(DependantHelper.class);

	public static Dependant copyValuesFromRequestBeanToEntity(DependantRequest DependantRequest) throws Exception {
		Dependant Dependant = new Dependant();
		Dependant.setDependantKey(NumberUtil.convertToLong(DependantRequest.getDependantKey()));
		Dependant.setEmployeeKey(NumberUtil.convertToLong(DependantRequest.getEmployeeKey()));
		Dependant.setAge(DependantRequest.getAge());
		Dependant.setLocation(DependantRequest.getLocation());
		Dependant.setName(DependantRequest.getName());
		Dependant.setRelation(DependantRequest.getRelation());
		Dependant.setCreateTs(DateUtil.convertToTimeStamp(DependantRequest.getCreateTs()));
		Dependant.setCreateUser(DependantRequest.getCreateUser());
		Dependant.setCreateSystem(DependantRequest.getCreateSystem());
		Dependant.setModifyTs(DateUtil.convertToTimeStamp(DependantRequest.getModifyTs()));
		Dependant.setModifyUser(DependantRequest.getModifyUser());
		Dependant.setModifySystem(DependantRequest.getModifySystem());
		return Dependant;
	}

	public static DependantResponse copyValuesFromEntityToResponse(Dependant Dependant,
			DependantResponse DependantResponse) {
		DependantResponse.setDependantKey("" + Dependant.getDependantKey());
		DependantResponse.setEmployeeKey("" + Dependant.getEmployeeKey());
		DependantResponse.setAge(Dependant.getAge());
		DependantResponse.setLocation(Dependant.getLocation());
		DependantResponse.setName(Dependant.getName());
		DependantResponse.setRelation(Dependant.getRelation());
		DependantResponse.setLockId("" + Dependant.getLockId());
		DependantResponse.setCreateTs("" + Dependant.getCreateTs());
		DependantResponse.setCreateUser(Dependant.getCreateUser());
		DependantResponse.setCreateSystem(Dependant.getCreateSystem());
		DependantResponse.setModifyTs("" + Dependant.getModifyTs());
		DependantResponse.setModifyUser(Dependant.getModifyUser());
		DependantResponse.setModifySystem(Dependant.getModifySystem());
		return DependantResponse;
	}

	public static List<Dependant> copyValuesFromReqBeanListToEntityList(DependantsRequest dependantsRequest)
			throws Exception {

		List<DependantRequest> DependantRequestList = dependantsRequest.getDependantRequestList();
		List<Dependant> DependantList = new ArrayList<Dependant>();
		for (int i = 0; i < DependantRequestList.size(); i++) {
			DependantRequest DependantRequest = DependantRequestList.get(i);
			Dependant Dependant = DependantHelper.copyValuesFromRequestBeanToEntity(DependantRequest);
			DependantList.add(Dependant);
		}
		return DependantList;
	}

	public static Dependant setAuditColumValuesForCreate(Dependant Dependant) throws Exception {
		Dependant = (Dependant) BeanUtil.setAuditColumValuesForCreate(Dependant);
		log.debug("AfterSetting AuditColm Dependant=" + Dependant);
		return Dependant;

	}

	public static Dependant setKeyColumnValue(Dependant Dependant) throws Exception {

		if ((Dependant.getDependantKey() == null) || (Dependant.getDependantKey() == 0)) {
			Long key = KeyGeneratorCustom.getKey();
			Dependant.setDependantKey(key);
		}
		return Dependant;

	}

	public static Dependant setAuditColumValuesForUpdate(Dependant Dependant) throws Exception {
		BeanUtil.setAuditColumValuesForUpdate(Dependant);
		return Dependant;
	}

}
