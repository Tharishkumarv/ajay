package com.easy.hr.employee.dao;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.easy.hr.employee.bean.Employee;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
@PropertySource(value = { "classpath:employee-dao.properties" })
public class EmployeeDAO {
	private static Logger log = Logger.getLogger(EmployeeDAO.class.getName());
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private NamedParameterJdbcTemplate namedJdbcTemplate;
	@Value(value = "${EmployeeDao.createEmployee}")
	private String createEmployeeQuery;
	@Value(value = "${EmployeeDao.updateEmployee}")
	private String updateEmployeeQuery;
	@Value(value = "${EmployeeDao.deleteEmployee}")
	private String deleteEmployeeQuery;
	@Value(value = "${EmployeeDao.getEmployee}")
	private String getEmployeeQuery;
	@Value(value = "${EmployeeDao.getEmployeeListByEmployeeKeyOtrs}")
	private String getEmployeeListByEmployeeKeyOtrs;
	@Value(value = "${EmployeeDao.getEmployeeListByEmployeeKeyList}")
	private String getEmployeeListByEmployeeKeyList;
	@Value(value = "${EmployeeDao.getEmployeeListByDynamicAttrs}")
	private String getEmployeeListByDynamicAttrs;
	@Value(value = "${EmployeeDao.getEmployeeListByEmployeeKeyOths}")
	private String getEmployeeListByEmployeeKeyOths;
	/** The batch insert size. */
	@Value(value = "${EmployeeDao.insertBatchSize}")
	private int batchInsertSize;

	/** The find Employee query. */
	@Value(value = "${EmployeeDao.findEmployeeQuery}")
	private String findEmployeeQuery;

	public void createEmployee(final Employee Employee) throws SQLException, DataAccessException {
		log.debug("createRecord start");
		log.debug("createRecord start");
		jdbcTemplate.execute(createEmployeeQuery, new PreparedStatementCallback<Object>() {
			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				int indx = 1;
				ps.setLong(indx++, Employee.getEmployeeKey());
				ps.setString(indx++, Employee.getDepartment());
				ps.setString(indx++, Employee.getDesignation());
				ps.setString(indx++, Employee.getEmployeeNo());
				ps.setString(indx++, Employee.getFirstName());
				ps.setString(indx++, Employee.getLastName());
				ps.setLong(indx++, Employee.getLockId());
				ps.setTimestamp(indx++, Employee.getCreateTs());
				ps.setString(indx++, Employee.getCreateUser());
				ps.setString(indx++, Employee.getCreateSystem());
				ps.setTimestamp(indx++, Employee.getModifyTs());
				ps.setString(indx++, Employee.getModifyUser());
				ps.setString(indx++, Employee.getModifySystem());

				return ps.executeUpdate();
			}
		});
	}

	public void updateEmployee(final Employee Employee) throws JsonParseException, JsonMappingException, IOException {

		log.debug("updateEmployee start");
		jdbcTemplate.execute(updateEmployeeQuery, new PreparedStatementCallback<Object>() {

			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				int indx = 1;
				ps.setString(indx++, Employee.getDepartment());
				ps.setString(indx++, Employee.getDesignation());
				ps.setString(indx++, Employee.getEmployeeNo());
				ps.setString(indx++, Employee.getFirstName());
				ps.setString(indx++, Employee.getLastName());
				ps.setLong(indx++, Employee.getLockId());
				ps.setTimestamp(indx++, Employee.getModifyTs());
				ps.setString(indx++, Employee.getModifyUser());
				ps.setString(indx++, Employee.getModifySystem());
				ps.setLong(indx++, Employee.getEmployeeKey());

				int count = ps.executeUpdate();
				log.debug("Number of records updated=" + count);
				if (count == 0)
					throw new SQLException("STALE_DATA_ERROR");
				return count;

			}

		});
		log.debug("updateEmployee end");

	}

	public void deleteEmployee(final Employee Employee) throws IOException {
		log.debug("deleteEmployee start");

		Long employeeKey = Employee.getEmployeeKey();
		log.debug("Key.=" + employeeKey);

		jdbcTemplate.execute(deleteEmployeeQuery, new PreparedStatementCallback<Object>() {

			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ps.setLong(1, Employee.getEmployeeKey());
				return ps.executeUpdate();
			}

		});
		log.debug("delete Employee end");
	}

	public Employee getEmployee(Employee Employee) {
		Long employeeKey = Employee.getEmployeeKey();

		log.debug("KeyCol for Get::" + employeeKey);
		Employee EmployeeFromDB = null;
		try {

			EmployeeFromDB = jdbcTemplate.queryForObject(getEmployeeQuery, new Object[] { employeeKey },
					new BeanPropertyRowMapper<Employee>(Employee.class));
			log.debug("VAlue=::" + EmployeeFromDB);
		} catch (EmptyResultDataAccessException ex) {
			log.info("No Record Found. It Maybe expected." + ex.toString());
			return null;
		}

		return EmployeeFromDB;
	}

	public Employee getEmployeeForUpdate(Employee Employee) {
		Long employeeKey = Employee.getEmployeeKey();

		log.debug("KeyCol for Get::" + employeeKey);
		Employee EmployeeFromDB = null;
		try {

			EmployeeFromDB = jdbcTemplate.queryForObject(getEmployeeQuery + " FOR UPDATE ",
					new Object[] { employeeKey }, new BeanPropertyRowMapper<Employee>(Employee.class));
			log.debug("VAlue=::" + EmployeeFromDB);
		} catch (EmptyResultDataAccessException ex) {
			log.info("NO RECORD. IT MAY BE EXPECTED." + ex.toString());
			return null;
		}

		return EmployeeFromDB;
	}

	public List<Employee> getEmployeeListByEmployeeKeyAndOtrs(Employee Employee) {
		log.debug("Employee::" + Employee);
		Object[] parameters = new Object[] { Employee.getEmployeeKey() };

		List<Employee> EmployeeObjListFromDB = jdbcTemplate.query(getEmployeeListByEmployeeKeyOtrs, parameters,
				new BeanPropertyRowMapper<Employee>(Employee.class));

		log.debug("No.Of RecordFoundCount in list=::" + EmployeeObjListFromDB.size());
		return EmployeeObjListFromDB;
	}

	public Employee getEmployeeByEmployeeKeyAndOtrs(Employee Employee) {
		List<Employee> EmployeeObjListFromDB = getEmployeeListByEmployeeKeyAndOtrs(Employee);
		Employee EmployeeFromDB = null;

		if (EmployeeObjListFromDB.size() > 0) {
			EmployeeFromDB = EmployeeObjListFromDB.get(EmployeeObjListFromDB.size() - 1);
			log.debug("EmployeeFromDBVAlue=::" + EmployeeObjListFromDB.get(EmployeeObjListFromDB.size() - 1));
		}

		return EmployeeFromDB;
	}

	public List<Employee> getEmployeeListByEmployeeKeyAndOths(Employee Employee) {
		log.debug("Employee::" + Employee);
		Object[] parameters = new Object[] { Employee.getEmployeeKey() };

		List<Employee> EmployeeObjListFromDB = jdbcTemplate.query(getEmployeeListByEmployeeKeyOths, parameters,
				new BeanPropertyRowMapper<Employee>(Employee.class));

		log.debug("No.Of RecordFoundCount in list=::" + EmployeeObjListFromDB.size());
		return EmployeeObjListFromDB;
	}

	public Employee getEmployeeByEmployeeKeyAndOths(Employee Employee) {
		List<Employee> EmployeeObjListFromDB = getEmployeeListByEmployeeKeyAndOths(Employee);
		Employee EmployeeFromDB = null;

		if (EmployeeObjListFromDB.size() > 0) {
			EmployeeFromDB = EmployeeObjListFromDB.get(EmployeeObjListFromDB.size() - 1);
			log.debug("EmployeeFromDBVAlue=::" + EmployeeObjListFromDB.get(EmployeeObjListFromDB.size() - 1));
		}

		return EmployeeFromDB;
	}

	public List<Employee> getEmployeeListByEmployeeKeyList(List<Employee> EmployeeList) {
		log.debug("EmployeeList::" + EmployeeList);
		String whereClause = " WHERE 1=2 ";
		List<Object> list = new ArrayList<Object>();
		for (Employee Employee : EmployeeList) {
			list.add(Employee.getEmployeeKey());
			whereClause = whereClause + " OR EMPLOYEE_KEY=? ";
		}

		Object[] parameters = list.toArray();

		List<Employee> EmployeeObjListFromDB = jdbcTemplate.query(getEmployeeListByEmployeeKeyList + whereClause,
				parameters, new BeanPropertyRowMapper<Employee>(Employee.class));

		log.debug("No.Of RecordFoundCount in list=::" + EmployeeObjListFromDB.size());
		return EmployeeObjListFromDB;
	}

	public List<Employee> getEmployeeListByDynamicAttrs(Employee Employee) {
		log.debug("Employee::" + Employee);
		List<Object> paramList = new ArrayList<Object>();
		String whereClause = " WHERE 1=1 ";
		if (Employee.getEmployeeKey() != null) {
			whereClause = whereClause + " AND EMPLOYEE_KEY=? ";
			paramList.add(Employee.getEmployeeKey());
		}
		if (Employee.getDepartment() != null) {
			whereClause = whereClause + " AND DEPARTMENT=? ";
			paramList.add(Employee.getDepartment());
		}
		if (Employee.getDesignation() != null) {
			whereClause = whereClause + " AND DESIGNATION=? ";
			paramList.add(Employee.getDesignation());
		}
		if (Employee.getEmployeeNo() != null) {
			whereClause = whereClause + " AND EMPLOYEE_NO=? ";
			paramList.add(Employee.getEmployeeNo());
		}
		if (Employee.getFirstName() != null) {
			whereClause = whereClause + " AND FIRST_NAME=? ";
			paramList.add(Employee.getFirstName());
		}
		if (Employee.getLastName() != null) {
			whereClause = whereClause + " AND LAST_NAME=? ";
			paramList.add(Employee.getLastName());
		}

		Object[] parameters = paramList.toArray();

		log.debug("DynamicSQL::" + getEmployeeListByDynamicAttrs + whereClause);
		List<Employee> EmployeeObjListFromDB = jdbcTemplate.query(getEmployeeListByDynamicAttrs + whereClause,
				parameters, new BeanPropertyRowMapper<Employee>(Employee.class));

		log.debug("No.Of RecordFoundCount in list=::" + EmployeeObjListFromDB.size());
		return EmployeeObjListFromDB;
	}

	public void insertEmployeeBatch(List<Employee> EmployeeList) throws SQLException {
		for (int i = 0; i < EmployeeList.size(); i += this.batchInsertSize) {
			final List<Employee> EmployeeBatch = EmployeeList.subList(i,
					i + this.batchInsertSize > EmployeeList.size() ? EmployeeList.size() : i + batchInsertSize);
			int[] noOfEmployeesInserted = jdbcTemplate.batchUpdate(this.createEmployeeQuery,
					new BatchPreparedStatementSetter() {
						public void setValues(PreparedStatement pStmt, int j) throws SQLException {
							Employee Employee = (Employee) EmployeeBatch.get(j);
							int indx = 1;
							pStmt.setLong(indx++, Employee.getEmployeeKey());
							pStmt.setString(indx++, Employee.getDepartment());
							pStmt.setString(indx++, Employee.getDesignation());
							pStmt.setString(indx++, Employee.getEmployeeNo());
							pStmt.setString(indx++, Employee.getFirstName());
							pStmt.setString(indx++, Employee.getLastName());
							pStmt.setLong(indx++, Employee.getLockId());
							pStmt.setTimestamp(indx++, Employee.getCreateTs());
							pStmt.setString(indx++, Employee.getCreateUser());
							pStmt.setString(indx++, Employee.getCreateSystem());
							pStmt.setTimestamp(indx++, Employee.getModifyTs());
							pStmt.setString(indx++, Employee.getModifyUser());
							pStmt.setString(indx++, Employee.getModifySystem());
							ObjectMapper mapper = new ObjectMapper();
							// Java objects to JSON string
							String jsonString = "";

							log.debug("attributes json" + jsonString);
							pStmt.setString(indx++, jsonString);
						}

						public int getBatchSize() {
							return EmployeeBatch.size();
						}
					});
			log.debug("insertEmployeesBatch end");
		}
	}

//##PLACE_FOR_PUB_API_DAO_CODE##// 
}
