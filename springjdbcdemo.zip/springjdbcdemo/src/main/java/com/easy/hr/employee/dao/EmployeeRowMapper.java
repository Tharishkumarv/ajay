package com.easy.hr.employee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.easy.hr.employee.bean.Employee;

public class EmployeeRowMapper implements RowMapper<Employee> {
	private static Logger log = Logger.getLogger(EmployeeRowMapper.class.getName());

	public Employee mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		Employee Employee = new Employee();
		Employee.setEmployeeKey(resultSet.getLong("EMPLOYEE_KEY"));
		Employee.setDepartment(resultSet.getString("DEPARTMENT"));
		Employee.setDesignation(resultSet.getString("DESIGNATION"));
		Employee.setEmployeeNo(resultSet.getString("EMPLOYEE_NO"));
		Employee.setFirstName(resultSet.getString("FIRST_NAME"));
		Employee.setLastName(resultSet.getString("LAST_NAME"));
		Employee.setLockId(resultSet.getLong("LOCK_ID"));
		Employee.setCreateTs(resultSet.getTimestamp("CREATE_TS"));
		Employee.setCreateUser(resultSet.getString("CREATE_USER"));
		Employee.setCreateSystem(resultSet.getString("CREATE_SYSTEM"));
		Employee.setModifyTs(resultSet.getTimestamp("MODIFY_TS"));
		Employee.setModifyUser(resultSet.getString("MODIFY_USER"));
		Employee.setModifySystem(resultSet.getString("MODIFY_SYSTEM"));
		return Employee;
	};
}
