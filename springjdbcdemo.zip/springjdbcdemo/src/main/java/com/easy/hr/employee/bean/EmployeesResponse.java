package com.easy.hr.employee.bean;

import java.util.ArrayList;
import java.util.List;

//import lombok.Getter;
//import lombok.Setter;
import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonResponse;
//import lombok.Getter;
//import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

//import lombok.Getter;
//import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeesResponse extends CommonResponse {

	private static Logger log = Logger.getLogger(EmployeesResponse.class);
	private static final long serialVersionUID = 1L;
	@JsonProperty("Employee")
	@XmlElement(name = "Employee")
	private List<EmployeeResponse> EmployeeResponseList = new ArrayList();

	public List<EmployeeResponse> getEmployeeResponseList() {
		return EmployeeResponseList;
	}

	public void setEmployeeResponseList(List<EmployeeResponse> EmployeeResponseList) {
		this.EmployeeResponseList = EmployeeResponseList;
	}

}
