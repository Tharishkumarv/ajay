package com.easy.hr.employee.bean;

import java.util.ArrayList;
import java.util.List;

//import lombok.Getter;
//import lombok.Setter;
import javax.xml.bind.annotation.XmlElement;

//import lombok.Getter;
//import lombok.Setter;
import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

//import lombok.Getter;
//import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeesRequest extends CommonRequest {

	private static Logger log = Logger.getLogger(EmployeesRequest.class);
	private static final long serialVersionUID = 1L;
	@JsonProperty("Employee")
	@XmlElement(name = "Employee")
	private List<EmployeeRequest> EmployeeRequestList = new ArrayList();

	public List<EmployeeRequest> getEmployeeRequestList() {
		return EmployeeRequestList;
	}

	public void setEmployeeRequestList(List<EmployeeRequest> EmployeeRequestList) {
		this.EmployeeRequestList = EmployeeRequestList;
	}
}
