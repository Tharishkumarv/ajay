package com.easy.hr.mainapi.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.easy.base.TransactionException;
import com.easy.hr.dependant.bean.Dependant;
import com.easy.hr.dependant.bean.DependantRequest;
import com.easy.hr.dependant.bean.DependantResponse;
import com.easy.hr.dependant.bean.Dependants;
import com.easy.hr.dependant.bean.DependantsRequest;
import com.easy.hr.dependant.bean.DependantsResponse;
import com.easy.hr.dependant.service.DependantHelper;
import com.easy.hr.employee.bean.Employee;
import com.easy.hr.employee.bean.EmployeeRequest;
import com.easy.hr.employee.bean.EmployeeResponse;
import com.easy.hr.employee.service.EmployeeHelper;
import com.easy.hr.mainapi.service.CreateEmployeeService;

@RestController
@RequestMapping(value = "/createEmployee/", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
		MediaType.APPLICATION_JSON_VALUE })
public class createEmployeeController {
	private static Logger log = Logger.getLogger(createEmployeeController.class);
	@Autowired
	private CreateEmployeeService service;

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<EmployeeRequest> test(@RequestBody @Valid EmployeeRequest employeeRequest,
			BindingResult result) throws Exception {
		log.debug("Update Demand. input =." + employeeRequest);

		return new ResponseEntity<EmployeeRequest>(employeeRequest, HttpStatus.OK);

	}

	@RequestMapping(value = { "/update", "/update/" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<EmployeeResponse> update(@RequestBody @Valid EmployeeRequest employeeRequest,
			BindingResult result) throws Exception {
		log.debug("Update input." + employeeRequest);

		Employee employee = this.copyValueFromRequestToEntity(employeeRequest);

		log.debug("employee Object=" + employee);
		CommonBean commonBean = service.create(employee, null);

		Employee employeeOutputObj = (Employee) commonBean;

		EmployeeResponse employeeResponse = this.copyFromTransBeanToResponse(employeeOutputObj);
		return new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.OK);
	}

	@RequestMapping(value = { "/create", "/create/" }, method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<EmployeeResponse> create(@RequestBody @Valid EmployeeRequest employeeRequest,
			BindingResult result) throws Exception {
		log.debug("Create input." + employeeRequest);

		Employee employee = this.copyValueFromRequestToEntity(employeeRequest);

		log.debug("employee Object=" + employee);
		CommonBean commonBean = service.create(employee, null);

		Employee employeeOutputObj = (Employee) commonBean;

		EmployeeResponse employeeResponse = this.copyFromTransBeanToResponse(employeeOutputObj);
		return new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.OK);
	}

	public Employee copyValueFromRequestToEntity(EmployeeRequest employeeRequest) throws Exception {

		Employee employee = EmployeeHelper.copyValuesFromRequestBeanToEntity(employeeRequest);
		DependantsRequest dependantsRequest = employeeRequest.getDependantsRequest();
		Dependants dependants = new Dependants();
		employee.setDependants(dependants);
		List<DependantRequest> dependantRequestList = dependantsRequest.getDependantRequestList();
		List<Dependant> dependantList = new ArrayList<Dependant>();
		dependants.setDependantList(dependantList);
		for (int k = 0; k < dependantRequestList.size(); k++) {
			DependantRequest dependantRequest = dependantRequestList.get(k);
			Dependant dependant = DependantHelper.copyValuesFromRequestBeanToEntity(dependantRequest);
			dependantList.add(dependant);

		} // ccn
		return employee;
	}

	public EmployeeResponse copyFromTransBeanToResponse(Employee employee) throws TransactionException {

		EmployeeResponse employeeResponse = new EmployeeResponse();
		EmployeeHelper.copyValuesFromEntityToResponse(employee, employeeResponse);// K2
		Dependants dependants = employee.getDependants();
		DependantsResponse dependantsResponse = new DependantsResponse();
		employeeResponse.setDependantsResponse(dependantsResponse);
		List<Dependant> dependantList = dependants.getDependantList();
		List<DependantResponse> dependantResponseList = new ArrayList<DependantResponse>();

		dependantsResponse.setDependantResponseList(dependantResponseList);

		for (int k = 0; k < dependantList.size(); k++) {
			Dependant dependant = dependantList.get(k);
			log.debug("Update Dependant has been Dependant=." + dependant);
			DependantResponse dependantResponse = new DependantResponse();
			dependantResponse = DependantHelper.copyValuesFromEntityToResponse(dependant, dependantResponse);
			dependantResponseList.add(dependantResponse);
		}
		return employeeResponse;
	}// M
}
