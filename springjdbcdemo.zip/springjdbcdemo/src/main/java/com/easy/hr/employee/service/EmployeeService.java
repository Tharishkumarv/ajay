package com.easy.hr.employee.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.easy.base.Service;
import com.easy.hr.employee.bean.Employee;
import com.easy.hr.employee.dao.EmployeeDAO;
@org.springframework.stereotype.Service
public class EmployeeService implements Service {
	private static Logger log = Logger.getLogger(EmployeeService.class.getName());
	@Autowired
	private EmployeeDAO EmployeeDAO;

	public CommonBean create(Employee Employee, Map<String, Object> params) throws Exception {
		log.debug("Create Employee has been initiated.");
		try {
			EmployeeDAO.createEmployee(Employee);
			return Employee;
		} catch (Exception exception) {
			log.error("Errorin.create", exception);
			throw exception;

		}
	}

	public CommonBean update(Employee Employee, Map<String, Object> params) throws Exception {

		log.debug("Update Employee has been initiated.");
		try {
			Employee EmployeeObjFromDB = EmployeeDAO.getEmployeeByEmployeeKeyAndOths(Employee); // change it to a
																								// correct method to get
																								// the Obj from DB.
			setValuesToDbObjectToUpdate(EmployeeObjFromDB, Employee);
			EmployeeDAO.updateEmployee(EmployeeObjFromDB);
			return EmployeeObjFromDB;
		} catch (Exception exception) {
			log.error("Employee.Update", exception);
			throw exception;
		}

	}

	private void setValuesToDbObjectToUpdate(Employee EmployeeObjFromDB, Employee Employee) throws Exception {

		if (Employee.getEmployeeKey() != null) {
			EmployeeObjFromDB.setEmployeeKey(Employee.getEmployeeKey());
		}
		if (Employee.getDepartment() != null) {
			EmployeeObjFromDB.setDepartment(Employee.getDepartment());
		}
		if (Employee.getDesignation() != null) {
			EmployeeObjFromDB.setDesignation(Employee.getDesignation());
		}
		if (Employee.getEmployeeNo() != null) {
			EmployeeObjFromDB.setEmployeeNo(Employee.getEmployeeNo());
		}
		if (Employee.getFirstName() != null) {
			EmployeeObjFromDB.setFirstName(Employee.getFirstName());
		}
		if (Employee.getLastName() != null) {
			EmployeeObjFromDB.setLastName(Employee.getLastName());
		}

	}

	public CommonBean manage(Employee Employee, Map<String, Object> params) throws Exception {

		log.debug("Update Employee has been initiated.");
		try {
			Employee EmployeeObjFromDB = EmployeeDAO.getEmployeeByEmployeeKeyAndOths(Employee); // change it to a
																								// correct method to get
																								// the Obj from DB.
			if (EmployeeObjFromDB == null) {
				create(Employee, params);
				return Employee;
			}
			setValuesToDbObjectToUpdate(EmployeeObjFromDB, Employee);
			EmployeeDAO.updateEmployee(EmployeeObjFromDB);
			return EmployeeObjFromDB;
		} catch (Exception exception) {
			log.error("Employee.Update", exception);
			throw exception;
		}
	}

	public CommonBean delete(Employee Employee, Map<String, Object> params) throws Exception {

		log.debug("delete Employee has been initiated.");
		try {
			Employee EmployeeObjFromDB = EmployeeDAO.getEmployeeByEmployeeKeyAndOths(Employee); // change it to a
																								// correct method to get
																								// the Obj from DB.
			EmployeeDAO.deleteEmployee(EmployeeObjFromDB);
			return EmployeeObjFromDB;
		} catch (Exception exception) {
			log.error("Employee.delete", exception);
			throw exception;
		}

		// log.debug("delete done EmployeeKey=" + Employee);

	}

	public CommonBean get(Employee Employee, Map<String, Object> params) throws Exception {
		log.debug("Update invDemandType has been initiated.");
		Employee EmployeeObjFromDB = null;
		try {
			EmployeeObjFromDB = EmployeeDAO.getEmployeeByEmployeeKeyAndOths(Employee); // Change it to correct mentods
			return EmployeeObjFromDB;
		} catch (Exception exception) {
			log.error("Employee.delete", exception);
			throw exception;
		}

	}

	public List<Employee> getEmployeeListByEmployeeKey(Employee Employee, Map<String, Object> params) throws Exception {
		log.debug("ListApi has been initiated.");
		List<Employee> EmployeeObjListFromDB = null;
		try {
			EmployeeObjListFromDB = EmployeeDAO.getEmployeeListByEmployeeKeyAndOtrs(Employee);
			return EmployeeObjListFromDB;
		} catch (Exception exception) {
			log.error("Employee.ListApi", exception);
			throw exception;
		}

	}

}
