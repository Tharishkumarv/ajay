package com.easy.hr.dependant.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonBean;
import com.easy.base.Service;
import com.easy.hr.dependant.bean.Dependant;
import com.easy.hr.dependant.dao.DependantDAO;

@org.springframework.stereotype.Service
public class DependantService implements Service {
	private static Logger log = Logger.getLogger(DependantService.class.getName());
	@Autowired
	private DependantDAO DependantDAO;

	public CommonBean create(Dependant Dependant, Map<String, Object> params) throws Exception {
		log.debug("Create Dependant has been initiated.");
		try {
			DependantDAO.createDependant(Dependant);
			return Dependant;
		} catch (Exception exception) {
			log.error("Errorin.create", exception);
			throw exception;

		}
	}

	public CommonBean update(Dependant Dependant, Map<String, Object> params) throws Exception {

		log.debug("Update Dependant has been initiated.");
		try {
			Dependant DependantObjFromDB = DependantDAO.getDependantByDependantKeyAndOths(Dependant); // change it to a
																										// correct
																										// method to get
																										// the Obj from
																										// DB.
			setValuesToDbObjectToUpdate(DependantObjFromDB, Dependant);
			DependantDAO.updateDependant(DependantObjFromDB);
			return DependantObjFromDB;
		} catch (Exception exception) {
			log.error("Dependant.Update", exception);
			throw exception;
		}

	}

	private void setValuesToDbObjectToUpdate(Dependant DependantObjFromDB, Dependant Dependant) throws Exception {

		if (Dependant.getDependantKey() != null) {
			DependantObjFromDB.setDependantKey(Dependant.getDependantKey());
		}
		if (Dependant.getEmployeeKey() != null) {
			DependantObjFromDB.setEmployeeKey(Dependant.getEmployeeKey());
		}
		if (Dependant.getAge() != null) {
			DependantObjFromDB.setAge(Dependant.getAge());
		}
		if (Dependant.getLocation() != null) {
			DependantObjFromDB.setLocation(Dependant.getLocation());
		}
		if (Dependant.getName() != null) {
			DependantObjFromDB.setName(Dependant.getName());
		}
		if (Dependant.getRelation() != null) {
			DependantObjFromDB.setRelation(Dependant.getRelation());
		}

	}

	public CommonBean manage(Dependant Dependant, Map<String, Object> params) throws Exception {

		log.debug("Update Dependant has been initiated.");
		try {
			Dependant DependantObjFromDB = DependantDAO.getDependantByDependantKeyAndOths(Dependant); // change it to a
																										// correct
																										// method to get
																										// the Obj from
																										// DB.
			if (DependantObjFromDB == null) {
				create(Dependant, params);
				return Dependant;
			}
			setValuesToDbObjectToUpdate(DependantObjFromDB, Dependant);
			DependantDAO.updateDependant(DependantObjFromDB);
			return DependantObjFromDB;
		} catch (Exception exception) {
			log.error("Dependant.Update", exception);
			throw exception;
		}
	}

	public CommonBean delete(Dependant Dependant, Map<String, Object> params) throws Exception {

		log.debug("delete Dependant has been initiated.");
		try {
			Dependant DependantObjFromDB = DependantDAO.getDependantByDependantKeyAndOths(Dependant); // change it to a
																										// correct
																										// method to get
																										// the Obj from
																										// DB.
			DependantDAO.deleteDependant(DependantObjFromDB);
			return DependantObjFromDB;
		} catch (Exception exception) {
			log.error("Dependant.delete", exception);
			throw exception;
		}

		// log.debug("delete done DependantKey=" + Dependant);

	}

	public CommonBean get(Dependant Dependant, Map<String, Object> params) throws Exception {
		log.debug("Update invDemandType has been initiated.");
		Dependant DependantObjFromDB = null;
		try {
			DependantObjFromDB = DependantDAO.getDependantByDependantKeyAndOths(Dependant); // Change it to correct
																							// mentods
			return DependantObjFromDB;
		} catch (Exception exception) {
			log.error("Dependant.delete", exception);
			throw exception;
		}

	}

	public List<Dependant> getDependantListByDependantKey(Dependant Dependant, Map<String, Object> params)
			throws Exception {
		log.debug("ListApi has been initiated.");
		List<Dependant> DependantObjListFromDB = null;
		try {
			DependantObjListFromDB = DependantDAO.getDependantListByDependantKeyAndOtrs(Dependant);
			return DependantObjListFromDB;
		} catch (Exception exception) {
			log.error("Dependant.ListApi", exception);
			throw exception;
		}

	}

}
