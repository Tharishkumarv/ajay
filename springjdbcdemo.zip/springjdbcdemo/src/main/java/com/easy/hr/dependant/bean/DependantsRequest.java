package com.easy.hr.dependant.bean;

import java.util.ArrayList;
import java.util.List;

//import lombok.Getter;
//import lombok.Setter;
import javax.xml.bind.annotation.XmlElement;

//import lombok.Getter;
//import lombok.Setter;
import org.apache.log4j.Logger;

//IMPORT_ALL_BEAN_CLASS
import com.easy.base.CommonRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

//import lombok.Getter;
//import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
public class DependantsRequest extends CommonRequest {

	private static Logger log = Logger.getLogger(DependantsRequest.class);
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "Dependant")
	@JsonProperty("dependant")
	private List<DependantRequest> dependantRequestList = new ArrayList();

	public List<DependantRequest> getDependantRequestList() {
		return dependantRequestList;
	}

	public void setDependantRequestList(List<DependantRequest> dependantRequestList) {
		this.dependantRequestList = dependantRequestList;
	}

	@Override
	public String toString() {
		String str = "|DependantRequestList=" + dependantRequestList;
		return str;
	}
}
